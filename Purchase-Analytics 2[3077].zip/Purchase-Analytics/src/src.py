import csv

# with open('/Users/enkhbat/fiverr/Purchase-Analytics/input/order_products.csv') as csvfile:
#     orders = csv.reader(csvfile, delimiter=',')
#     for row in orders:
#         print(row)
#         # print(row[0])
#         # print(row[0],row[1],row[2],row[3])

# with open('/Users/enkhbat/fiverr/Purchase-Analytics/input/products.csv') as csvfile:
#     products = csv.reader(csvfile, delimiter=',')
#     for row in products:
#         print(row)
#         # print(row[0])
#         # print(row[0],row[1],row[2],row[3])


# myData = [[1, 2, 3], ['Good Morning', 'Good Evening', 'Good Afternoon']]

csv.register_dialect('myDialect', delimiter='/', quoting=csv.QUOTE_NONE)

myFile = open('csvexample4.csv', 'w')  
with myFile:  
   writer = csv.writer(myFile, dialect='myDialect')
   writer.writerows(myData)