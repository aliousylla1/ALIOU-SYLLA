import csv
# ---------------reading  order_products.csv file -----------

with open('/Users/enkhbat/fiverr/Purchase-Analytics/input/order_products.csv') as csvfile:
    orders = csv.reader(csvfile, delimiter=',')
    order_id=[]
    reordered=[]
    product_id=[]
    for order in orders:
        print(order)
        order_id.append(order[0])
        product_id.append(order[1])
        reordered.append(order[3])

# ------------------Made a dictionary -------------------
order_dic={'order_id':[int(i) for i in order_id[1:]], 'product_id':[int(i) for i in product_id[1:]], 
            'reordered':[int(i) for i in reordered[1:]]}


# ---------------reading  products.csv file -----------


with open('/Users/enkhbat/fiverr/Purchase-Analytics/input/products.csv') as csvfile:
    products = csv.reader(csvfile, delimiter=',')
    product_id=[]
    department_id=[]
    for product in products:
        product_id.append(product[0])
        department_id.append(product[3])
        print(product)
   
#--------------made a second dictionary ------------------------

product_dic={'product_id':[int(i) for i in product_id[1:]], 
             'department_id':[int(i) for i in department_id[1:]]}

# ------------made a new dictionary from above two-------------
new_dic={}
new_dic['department_id']=list(set(product_dic['department_id']))

[product_dic['department_id'][i] for i in range(len(product_dic['product_id'])) if product_dic['product_id'][i] in order_dic['product_id']]
new_dic['number_of_orders']=[]
for i in new_dic['department_id']:
    new_dic['number_of_orders'].append(product_dic['department_id'].count(i))


new_list=[product_dic['department_id'][i] for i in range(len(product_dic['product_id'])) 
          if order_dic['reordered'][i]==0]
new_dic['number_of_first_orders']=[]
for i in new_dic['department_id']:
    new_dic['number_of_first_orders'].append(new_list.count(i))

new_dic['percentage']=[(new_dic['number_of_first_orders'][i]/new_dic['number_of_orders'][i])
                       for i in range(len(new_dic['number_of_orders']))]

#-----------------------------file saved in output directory as report.csv-------------------------


with open('/Users/enkhbat/fiverr/Purchase-Analytics/output/report.csv', mode='w') as csvfile:
    fieldnames = ['department_id','number_of_orders','number_of_first_orders','percentage']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(len(new_dic)):
        writer.writerow({'department_id': new_dic['department_id'][i], 'number_of_orders':new_dic['number_of_orders'][i],\
            'number_of_first_orders': new_dic['number_of_first_orders'][i],'percentage':new_dic['percentage'][i]})

print(new_dic)

