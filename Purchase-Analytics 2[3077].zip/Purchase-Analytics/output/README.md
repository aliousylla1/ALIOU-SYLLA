This directory is where we would expect your program to write the requested output files.
